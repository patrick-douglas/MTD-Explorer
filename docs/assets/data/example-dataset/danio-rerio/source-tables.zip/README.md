# Danio rerio exploratory case study: source tables

Analytical commit: 5be26aa2e03938abb12fe00a37a08b0c0cef3777.
Run date: 2026-11-25. BioProject PRJNA1005695; six selected libraries.

The `outputs/` subtree preserves the original paths and bytes of selected scientific tables from the definitive run. The `provenance/` subtree contains the selected public ENA/BioSample metadata, FASTQ MD5 manifest, samplesheet, reference catalog row, stage timings, figure-source map, and run parameters. The parameters and fastp runtime table replace the original `/home/me/` prefix with `$HOME/` for portability; they are not byte-identical to the original reports. This archive excludes raw reads, large alignment and database intermediates, and full execution logs. It is a source-data companion, not a complete reference-database snapshot. The exact analytical source is identified by the commit above; database content can change between installations.

All taxonomic assignments and functional profiles are computational outputs, not validated biological identifications.
