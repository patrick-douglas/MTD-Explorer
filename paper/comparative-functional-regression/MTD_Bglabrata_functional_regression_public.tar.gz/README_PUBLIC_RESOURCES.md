# Public regression archive — external dictionaries

This is a repackaging of the historical regression archive (SHA-256 `0617d1f247bc5f3d3abbd50f362de7ba0c0e5d5828b6679b9f5b2e8ffbb3e59d`). It is not a new computational run. Exactly two complete historical dictionary files were omitted: `inputs/goterms.txt` and `inputs/koterms.txt`. All 171 retained original files are byte-identical. Existing derived tables and figures, including functional labels, are unchanged; their redistribution conditions require separate review. The historical dictionary release dates are unknown.

## Verify the public archive

From the extraction directory:

```bash
sha256sum -c provenance/public_archive_files.sha256
sha256sum -c provenance/public_input_and_source.sha256
cat provenance/stage_status.tsv
```

The original `provenance/input_and_source.sha256` and `provenance/input_integrity_after.txt` are preserved as historical evidence, not rewritten. The original manifest will report two missing files until the external dictionaries have been supplied. The original output inventory describes the full local run and may list outputs not selected for this archive.

## Optional: restore exact historical inputs locally

Obtain the original dictionaries through authorized channels, or use existing local copies if entitled to retain them. Do not commit them to Git or redistribute them. See the [GO license](https://geneontology.org/page/use-and-license), [KEGG terms](https://www.genome.jp/kegg/legal.html), and the repository's `docs/getting-started/functional-resources.md`. Different dictionary releases may not reproduce historical labels. Exact historical hashes:

```text
3f0ed5ec2dbd1c7a4f38db10170349207c4953108cded7063733684404af3a74  inputs/goterms.txt
88ad9fac54da282c34b1126f7fa3adb40b8d728659ab4cae406b8f4f25de6f9e  inputs/koterms.txt
```

Copy the files to the indicated paths, then run `sha256sum -c provenance/input_and_source.sha256`. The archived `provenance/run_script.sh` is the original execution record and requires local paths, historical inputs and dependencies to rerun. The public archive supports inspection of the saved results without the two external dictionaries, not an unconditional claim of exact rerunnability or legal clearance.
