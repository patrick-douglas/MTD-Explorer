#!/usr/bin/env bash
# Paired regression of the exact pre-patch and corrected functional modules.
set -euo pipefail
REPO=${REPO:-$HOME/MTD-Explorer}
BGL=${BGL:-/media/me/18TB_BACKUP_LBN/drive.ifpa/LBN_RNA-Seq/Metatranscriptomics/MTD-Explorer/test_MTD_explorer_B.glabrata.extract_top5_trim}
PRE=af59f09
POST=5be26aa2e03938abb12fe00a37a08b0c0cef3777
HUM=aux_scripts/analysis/humann
DEG=aux_scripts/analysis/differential
CONDA=${CONDA_EXE:-$HOME/miniconda3/bin/conda}
[[ -x "$CONDA" ]] || { echo "Conda executable not found: $CONDA" >&2; exit 1; }
for rev in "$PRE" "$POST"; do git -C "$REPO" rev-parse --verify "$rev^{commit}" >/dev/null; done
for f in "$BGL/methods/used_samplesheet.csv" "$BGL/methods/mtd_methods_run_parameters.csv" "$BGL/kraken/kraken_host_summary.tsv" "$REPO/HostSpecies.csv" "$REPO/$HUM/koterms.txt" "$REPO/$HUM/goterms.txt" "$BGL/hmn_genefamily_abundance_files/humann_genefamilies_Abundance_go.tsv" "$BGL/hmn_genefamily_abundance_files/humann_genefamilies_Abundance_kegg.tsv"; do
    [[ -s "$f" ]] || { echo "Missing required input: $f" >&2; exit 1; }
done
ROOT=$(mktemp -d "$HOME/MTD_Bglabrata_functional_regression_XXXXXXXX")
echo "$ROOT" > "$HOME/MTD_Bglabrata_functional_regression_latest.txt"
mkdir -p "$ROOT"/{inputs,source,logs,provenance,historical}
cp "$BGL/methods/used_samplesheet.csv" "$BGL/methods/mtd_methods_run_parameters.csv" "$BGL/kraken/kraken_host_summary.tsv" "$ROOT/inputs/"
cp "$BGL/hmn_genefamily_abundance_files/"humann_genefamilies_Abundance_{go,kegg}.tsv "$ROOT/inputs/"
cp "$REPO/$HUM/"{koterms,goterms}.txt "$ROOT/inputs/"
cp "$REPO/HostSpecies.csv" "$ROOT/inputs/"
python3 - "$ROOT/inputs" <<'PY'
import csv, pathlib, sys
p=pathlib.Path(sys.argv[1])
with (p/'used_samplesheet.csv').open() as f: rows=list(csv.DictReader(f))
samples=[r['sample_name'] for r in rows]
groups={r['group'] for r in rows}
contrasts={(r['group1'],r['group2']) for r in rows if r['group1'] and r['group2']}
assert len(samples)==len(set(samples))==15, samples
assert len(groups)==3 and len(contrasts)==3 and all(a in groups and b in groups and a!=b for a,b in contrasts), (groups,contrasts)
with (p/'kraken_host_summary.tsv').open() as f: host=list(csv.DictReader(f,delimiter='\t'))
assert len(host)==15 and {r['sample'] for r in host}==set(samples), 'Host summary sample mismatch'
assert all(float(r['host_classified_reads'])+float(r['host_unclassified_reads'])>0 for r in host)
for rank in ('go','kegg'):
    with (p/f'humann_genefamilies_Abundance_{rank}.tsv').open() as f: h=next(csv.reader(f,delimiter='\t'))
    cols=[v[:-len('_Abundance-RPKs')] if v.endswith('_Abundance-RPKs') else v for v in h[1:]]
    assert len(cols)==15 and set(cols)==set(samples), (rank,cols,samples)
print('Input checks passed: 15 samples, 3 groups, 3 contrasts', sorted(contrasts))
PY
for label in before after; do
    if [[ $label == before ]]; then rev=$PRE; else rev=$POST; fi
    mkdir -p "$ROOT/source/$label" "$ROOT/$label/kraken" "$ROOT/$label/hmn_genefamily_abundance_files"
    for f in "$HUM/humann_ID_translation_adjusted.R" "$DEG/DEG_Anno_Plot.R" "$DEG/MTD_humann_feature_overlap_venn.R"; do
        git -C "$REPO" show "$rev:$f" > "$ROOT/source/$label/${f##*/}"
    done
    git -C "$REPO" rev-parse "$rev^{commit}" > "$ROOT/provenance/${label}_commit.txt"
    cp "$ROOT/inputs/kraken_host_summary.tsv" "$ROOT/$label/kraken/"
    cp "$ROOT/inputs/"humann_genefamilies_Abundance_{go,kegg}.tsv "$ROOT/$label/hmn_genefamily_abundance_files/"
done
# Pin the dictionaries and input data to the same copies for both runs.
(cd "$ROOT"; find inputs source -type f -print0 | sort -z | xargs -0 sha256sum) > "$ROOT/provenance/input_and_source.sha256"
git -C "$REPO" status --short > "$ROOT/provenance/repository_status.txt"
cp "${BASH_SOURCE[0]}" "$ROOT/provenance/run_script.sh"
export R_LIBS_USER="$REPO/custom_R_libs:${R_LIBS_USER:-}"
for env in R412 MTD_fastp; do
    "$CONDA" list -n "$env" --explicit > "$ROOT/provenance/conda_${env}_explicit.txt"
    "$CONDA" run -n "$env" --no-capture-output Rscript -e 'sessionInfo(); print(installed.packages()[,c("Package","Version"),drop=FALSE])' > "$ROOT/provenance/R_${env}_packages.txt" 2>&1
done
# Archive original summary/contrast tables for context only; do not alter them.
for rank in GO KEGG; do
    hist="$BGL/hmn_genefamily_abundance_files/Nonhost_hmn_DEG/$rank"
    if [[ -d "$hist" ]]; then
        (cd "$hist"; find . -type f \( -name '*.csv' -o -name '*.tsv' -o -name '*.txt' \) -size -20M -print0 | tar --null -T - -cf -) | (mkdir -p "$ROOT/historical/$rank"; tar -xf - -C "$ROOT/historical/$rank")
    fi
done
printf 'stage\tstatus\texit_code\tlog\n' > "$ROOT/provenance/stage_status.tsv"
stage() {
    local name=$1; shift
    local rc
    echo "=== $name ==="
    if /usr/bin/time -v "$@" > "$ROOT/logs/$name.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\t%s\t%s\t%s\n' "$name" "$([[ $rc == 0 ]] && echo PASS || echo FAIL)" "$rc" "logs/$name.log" >> "$ROOT/provenance/stage_status.tsv"
    tail -n 12 "$ROOT/logs/$name.log"
    return "$rc"
}
for label in before after; do
    work="$ROOT/$label/hmn_genefamily_abundance_files"
    src="$ROOT/source/$label"
    if ! stage "${label}_translation" "$CONDA" run -n R412 --no-capture-output Rscript "$src/humann_ID_translation_adjusted.R" "$work/humann_genefamilies_Abundance_kegg.tsv" "$work/humann_genefamilies_Abundance_go.tsv" "$ROOT/inputs"; then continue; fi
    for rank in KEGG GO; do
        stem="humann_genefamilies_Abundance_${rank,,}_translated"
        out="$work/Nonhost_hmn_DEG/$rank"
        if [[ $label == after && ! -s "$work/${stem}_id_map.tsv" ]]; then
            printf '%s\tFAIL\t1\tmissing_id_map\n' "${label}_${rank}_DEG" >> "$ROOT/provenance/stage_status.tsv"
            continue
        fi
        if ! stage "${label}_${rank}_DEG" "$CONDA" run -n R412 --no-capture-output Rscript "$src/DEG_Anno_Plot.R" "$work/$stem.tsv" "$ROOT/inputs/used_samplesheet.csv" 6526 "$REPO/HostSpecies.csv"; then continue; fi
        if [[ ! -s "$out/${stem}_DEG.csv" ]]; then
            printf '%s\tFAIL\t1\tmissing_DEG_csv\n' "${label}_${rank}_overlap" >> "$ROOT/provenance/stage_status.tsv"
            continue
        fi
        stage "${label}_${rank}_overlap" "$CONDA" run -n MTD_fastp --no-capture-output Rscript "$src/MTD_humann_feature_overlap_venn.R" --input "$out/${stem}_DEG.csv" --samplesheet "$ROOT/inputs/used_samplesheet.csv" --feature_type "$rank" --plot_type both --output "$out/venn_diagramm.pdf" --euler_output "$out/euler_diagramm.pdf" --write_summary --write_lists || true
    done
done
# R may catch MaAsLin2 errors and return zero. Record those independently.
find "$ROOT/before" "$ROOT/after" -type f -name MTD_MaAsLin2_ERROR.txt -printf '%P\n' > "$ROOT/provenance/maaslin_errors.txt"
(cd "$ROOT"; find before after -type f -printf '%s\t%p\n' | sort) > "$ROOT/provenance/output_inventory.tsv"
(cd "$ROOT"; sha256sum -c provenance/input_and_source.sha256) > "$ROOT/provenance/input_integrity_after.txt"
# Keep complete outputs locally; export tables, logs, and selected plot files.
ARCHIVE="$ROOT.tar.gz"
(cd "$ROOT"; { find inputs source provenance logs historical -type f -print0; find before after -type f \( -name '*.csv' -o -name '*.tsv' -o -name '*.txt' -o -name '*.log' -o -name 'venn_diagramm.pdf' -o -name 'euler_diagramm.pdf' -o -name 'PCA_color.pdf' -o -name 'heatmap_thumbnail.pdf' \) -print0; } | sort -zu | tar --null -T - -czf "$ARCHIVE")
tar -tzf "$ARCHIVE" >/dev/null
cat "$ROOT/provenance/stage_status.tsv"
echo "=== MaAsLin2 error markers ==="
cat "$ROOT/provenance/maaslin_errors.txt"
echo "=== Full outputs: $ROOT ==="
ls -lh "$ARCHIVE"
if grep -q $'\tFAIL\t' "$ROOT/provenance/stage_status.tsv" || [[ -s "$ROOT/provenance/maaslin_errors.txt" ]] || [[ $(($(wc -l < "$ROOT/provenance/stage_status.tsv")-1)) != 10 ]]; then
    echo '[WARNING] Regression completed with failed or skipped stages. Inspect archive.' >&2; exit 1
fi
echo '[OK] All subprocesses completed. Numerical regression audit remains pending.'
